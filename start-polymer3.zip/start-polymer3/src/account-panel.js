import {PolymerElement, html} from '@polymer/polymer';
import '@polymer/paper-header-panel/paper-header-panel.js';
import '@polymer/paper-toolbar/paper-toolbar.js';
import '@polymer/iron-icon/iron-icon.js';
import '@polymer/polymer/lib/elements/dom-if.js';
import './card-panel'
import './accountdetails-panel'

class AccountPanel extends PolymerElement {

    constructor() {
        super();
        this.addEventListener('click', this.toggle.bind(this));
    }

    ready(){
        super.ready();
        if(this.accounts){
            this.accounts.forEach(element =>{
                this.totalamount += Number(element.amount);
            })
        }
        
    }

    static get properties() {
        return {
            "currency": {
                type: String,
                value: 'S$ '
            },
            "totalamount": {
                type: Number,
                value: 0
            },
            "accountname": {
                type: String,
                value: 'Credit Cards'
            },
            "showAccounts": {
                type: Boolean,
                value: false,
            },
            "showNewStatement": {
                type: Boolean,
                value: true,
            },
            "showFlag": {
                type: Boolean,
                value: false,
            },
            "arrow": {
                type: String,
                value: "d"
            },
            accounts: {
                value() {
                    return [
                        {currency: 'S$ ', amount: '3500.50',cardname: "Rewards ****1781", hasnewstatement: true, dueamount:"850.22", minpayment:"250.41"},
                        {currency: 'S$ ', amount: '500.32',cardname: "Rewards ****1234", hasnewstatement: false},
                        {currency: 'S$ ', amount: '1500.07',cardname: "Rewards ****5509", hasnewstatement: false} 
                    ];
                }
            }
        }
    }

    static get template() {
      return html`
        <style>
            .panel{
                padding: 15px;
                height: 60px;
            }
            .panel-item{
                display: inline-block;
            }
            .arrow{
                line-height: 60px;
                float: right;
            }
            .view-btn{
                border-radius: 30px;
            }
        </style>
        <div class='panel'>
            <card-panel currency='{{currency}}' amount='{{totalamount}}' cardname='{{accountname}}'></card-panel>
            <div class='panel-item arrow'>
                <paper-button class='view-btn'><iron-icon src="manifest/icon/arrow-{{arrow}}.svg"></iron-icon></paper-button>
            </div>
        </div>
        <template is="dom-if" if=[[showFlag]]>
            <div id='details'>
                <dom-repeat id="accountList" items="{{accounts}}">
                    <template>
                        <accountdetails-panel currency='{{item.currency}}' amount='{{item.amount}}' hasnewstatement='{{item.hasnewstatement}}' cardname='{{item.cardname}}'  dueamount='{{item.dueamount}}' minpayment='{{item.minpayment}}' ></accountdetails-panel>
                    </template>
                </dom-repeat>
            </div>
        </template>
      `;
    }
    
    toggle(e){

        let isaccountdetails = false;
        e.path.forEach(element => {
            if(element.localName === "accountdetails-panel"){
                isaccountdetails = true;
            }
        });

        if(isaccountdetails) return;

        this.showFlag = !this.showFlag;

        if(this.showFlag){
            this.arrow = "u";
        }else{
            this.arrow = "d"; 
        }
    }

}
customElements.define('account-panel', AccountPanel);
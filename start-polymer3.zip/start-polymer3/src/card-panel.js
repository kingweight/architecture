import {PolymerElement, html} from '@polymer/polymer';
import "./amount-label"

class CardPanel extends PolymerElement {

    static get properties() {
        return {
            "currency": {
                type: String,
                value: 'S$ '
            },
            "amount": {
                type: String,
                value: ''
            },
            "cardname": {
                type: String,
                value: ''
            },
        }
    }

    static get template() {
        return html`
        <style>
            .panel-item{
                display: inline-block;
            }
            .cardname{
                padding: 0 0 7px 0;
                color: dimgray;
            }
        </style>
        <div class='panel-item'>
            <div class='cardname'>{{cardname}}</div>
            <amount-label currency='{{currency}}' amount='{{amount}}'></amount-label>
        </div>
        `
    }

}
customElements.define('card-panel', CardPanel);
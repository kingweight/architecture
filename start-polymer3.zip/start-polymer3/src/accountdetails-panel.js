import {PolymerElement, html} from '@polymer/polymer';
import '@polymer/paper-icon-button/paper-icon-button.js';
import '@polymer/paper-button/paper-button.js';
import './date-label'

class AccountDetailsPanel extends PolymerElement {

    static get properties() {
        return {
            "currency": {
                type: String,
                value: ''
            },
            "amount": {
                type: String,
                value: ''
            },
            "cardname": {
                type: String,
                value: ''
            },
            "dueamount":{
                type: String,
                value: '0.00'
            },
            "minpayment":{
                type: String,
                value: '0.00'
            },
            "inputDateString":{
                type: String,
                value: '19 June'
            },
            "hasnewstatement":{
                type: Boolean,
                value: ''
            }
        }
    }

    ready(){
        super.ready();
    }

    static get template() {
        return html`
        <style>
            .panel{
                padding: 15px;
                height: 60px;
            }
            .arrow-right{
                line-height: 60px;
                float: right;
                display: inline-block;
            }
            .arrow-left{
                padding: 15px 15px 0 30px;
                width: 100px;
                line-height: 60px;
                float: left;
                display: inline-block;
            }
            .card{
                width: 100%;
                height: 100%;
            }
            .newstatement{
                margin: 0px 15px 20px 15px;
                padding: 10px 15px;
                color: blue;
                background-color: aliceblue;
                border-radius: 40px;
            }
            .pay-btn{
                background-color: skyblue;
                width: 100px;
                border-radius: 30px;
            }
            .view-btn{
                width: 100px;
                border-radius: 30px;
            }
        </style>
        <div>
            <template is="dom-if" if=[[hasnewstatement]]>
                <div class='newstatement'>
                    New Statement
                </div>
            </template>
            <div>
                <div class='arrow-left'>
                    <iron-icon class='card' src="manifest/images/rewardsCard.jpg"></iron-icon>
                </div>
                <div class='panel'>
                    <card-panel currency='{{currency}}' amount='{{amount}}' cardname='{{cardname}}'></card-panel>
                    <div class='arrow-right'>
                    <iron-icon style='height:15px' src="manifest/icon/arrow-r.svg"></iron-icon>
                    </div>
                </div>
            </div>
            <template is="dom-if" if=[[hasnewstatement]]>
                <div style='padding: 15px 15px 15px 20px;'>
                    <div>Amount due on <date-label inputDateString='{{inputDateString}}'></date-label> <span style='font-size:larger;font-weight: 600;'>{{currency}} {{dueamount}}</span></div>
                    <div>Min Payment <span style='font-size:larger;font-weight: 600;'>{{currency}} {{minpayment}}</span></div>
                </div>
                <div style='padding: 5px 15px 15px 15px;'>
                    <paper-button class='view-btn'><iron-icon src="manifest/icon/detail.svg"></iron-icon>&nbsp;&nbsp;View</paper-button>
                    <paper-button class='pay-btn'><iron-icon src="manifest/icon/payout.svg"></iron-icon>&nbsp;&nbsp;Pay</paper-button>
                </div>
            </template>
        </div>
        `
    }

}

customElements.define('accountdetails-panel', AccountDetailsPanel);
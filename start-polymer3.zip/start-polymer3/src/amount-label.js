import {PolymerElement, html} from '@polymer/polymer';

class AmountLabel extends PolymerElement {

    static get properties() {
        return {
            "currency": {
                type: String,
                value: 'S$ '
            },
            "amount": {
                type: String,
                value: ''
            }, 
            "format":{
                type: String,
                value: '0.00'
            }          
        }
    }

    static get template() {
        return html`
        <style>
            .panel-item{
                display: inline-block;
            }
            .amount{
                font-size: x-large;
            }
        </style>
        <div class='amount'>
            <div class='panel-item'>{{currency}}</div>
            <div class='panel-item'>{{amount}}</div>
        </div>
        `
    }

}

customElements.define('amount-label', AmountLabel);
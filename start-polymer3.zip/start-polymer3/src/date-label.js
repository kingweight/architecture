import {PolymerElement, html} from '@polymer/polymer';

class DateLabel extends PolymerElement {

    static get properties() {
        return {
            "inputDateString": {
                type: String,
                value: '19 June '
            },
            "inputFormat": {
                type: String,
                value: 'yyyy-mm-dd'
            }, 
            "outputFormat":{
                type: String,
                value: 'yyyy-mm-dd'
            },
            "outputDateString": {
                type: String,
                value: '19 June '
            }
        }
    }

    ready(){
        super.ready();
        //format input datestring here.
    }

    static get template() {
        return html`
        <style>
            .datestring{
                display: inline-block;
            }
        </style>
        <div class='datestring'>{{outputDateString}}</div>
        `
    }

}
customElements.define('date-label', DateLabel);